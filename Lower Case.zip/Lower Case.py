if __name__ == "__main__":
    name = input("Enter your name: ")
    lower_case_name = name.lower()
    print(f"Your name in lower case is: {lower_case_name}")
