numbers = [10, 20, 30, 40, 50]
total = sum(numbers)
print("The sum of all items in the list is:", total)
