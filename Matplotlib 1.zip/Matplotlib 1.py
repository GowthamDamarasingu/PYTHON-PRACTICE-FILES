import matplotlib.pyplot as plt
days = list(range(1, 32))  # Days of the month (1 to 31)
temperature = [65, 68, 70, 72, 75, 76, 78, 80, 81, 79, 75, 72, 70, 68, 67, 69, 70, 73, 75, 76, 78, 80, 81, 82, 83, 82, 80, 78, 76, 74, 71]
plt.figure(figsize=(10,6))
plt.plot(days, temperature, marker='o', color='b', linestyle='-', linewidth=2, markersize=6)
plt.title('Daily Temperature Changes in a City Over 31 Days', fontsize=14)
plt.xlabel('Day of the Month', fontsize=12)
plt.ylabel('Temperature (°F)', fontsize=12)
plt.grid(True)
plt.show()
