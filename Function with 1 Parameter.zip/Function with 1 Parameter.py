def square(num):
    return num ** 2

if __name__ == "__main__":
    try:
        number = float(input("Enter a number: "))
        result = square(number)
        print(f"The square of {number} is: {result}")
    except ValueError:
        print("Please enter a valid number.")
