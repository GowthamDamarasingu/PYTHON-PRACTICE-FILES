numbers = [45, 12, 78, 34, 90, 3, 56]
largest = numbers[0]
smallest = numbers[0]
for number in numbers:
    if number > largest:
        largest = number
    if number < smallest:
        smallest = number
print("The largest number in the list is:", largest)
print("The smallest number in the list is:", smallest)
