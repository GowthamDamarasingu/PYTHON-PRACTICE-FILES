def calculate_net_amount(product_code, order_amount):
    discount = 0

    if product_code == 1 and order_amount > 1000:
        discount = 0.10
    elif product_code == 3 and order_amount > 500:
        discount = 0.10

    net_amount = order_amount * (1 - discount)
    return net_amount

if __name__ == "__main__":
    try:
        product_code = int(input("Enter the product code (1: Battery Based, 2: Key-based, 3: Electrical Charging): "))
        order_amount = float(input("Enter the order amount: "))

        if product_code not in [1, 2, 3]:
            print("Invalid product code. Please enter 1, 2, or 3.")
        else:
            net_amount = calculate_net_amount(product_code, order_amount)
            print(f"The net amount to be paid is: Rs. {net_amount:.2f}")
    except ValueError:
        print("Please enter valid numeric values.")
