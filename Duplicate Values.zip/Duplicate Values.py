numbers = [10, 20, 30, 10, 40, 50, 20, 60, 70, 30]
duplicates = []
seen = set()
for number in numbers:
    if number in seen:
        if number not in duplicates:
            duplicates.append(number)
    else:
        seen.add(number)
if duplicates:
    print("Duplicate values in the list are:", duplicates)
else:
    print("No duplicates found.")
