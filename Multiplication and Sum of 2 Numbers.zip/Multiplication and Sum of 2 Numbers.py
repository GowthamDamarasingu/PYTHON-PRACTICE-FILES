def calculate_operations(num1, num2):
    multiplication = num1 * num2
    summation = num1 + num2
    return multiplication, summation

if __name__ == "__main__":
    try:
        number1 = float(input("Enter the first number: "))
        number2 = float(input("Enter the second number: "))
        multiplication, summation = calculate_operations(number1, number2)
        print(f"The multiplication of {number1} and {number2} is: {multiplication}")
        print(f"The sum of {number1} and {number2} is: {summation}")
    except ValueError:
        print("Please enter valid numbers.")
