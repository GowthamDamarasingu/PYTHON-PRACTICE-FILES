original_list = ['red', 'green', 'white', 'black']
print("Traverse the said list in reverse order:")
for index in range(len(original_list) - 1, -1, -1):
    print(original_list[index])
