import random

random_numbers = [random.randint(1, 100) for _ in range(5)]

maximum = max(random_numbers)
minimum = min(random_numbers)

print(f"Random numbers: {random_numbers}")
print(f"The maximum number is: {maximum}")
print(f"The minimum number is: {minimum}")
